var wins = 0;
function start(){
	var x = Math.random();

	if (x < 1/3){
		document.getElementById("CompChoice").innerHTML="paper";
	}else if (x < 2.3){
		document.getElementById("CompChoice").innerHTML="rock";
	}else{
		document.getElementById("CompChoice").innerHTML="scissors";
	}
}